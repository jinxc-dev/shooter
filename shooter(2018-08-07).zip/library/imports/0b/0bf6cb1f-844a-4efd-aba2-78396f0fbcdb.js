"use strict";
cc._RF.push(module, '0bf6csfhEpO/auieDlvD7zb', 'fadeBtn');
// script/component/fadeBtn.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        var s1 = cc.fadeIn(0.5);
        var s2 = cc.fadeOut(1);
        this.node.runAction(cc.sequence(s2, s1).repeatForever());
    }
}

// update (dt) {},
);

cc._RF.pop();