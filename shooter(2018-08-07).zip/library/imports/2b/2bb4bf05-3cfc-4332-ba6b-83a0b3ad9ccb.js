"use strict";
cc._RF.push(module, '2bb4b8FPPxDMrprg6CzrZzL', 'rankTopView');
// script/component/rankTopView.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        this.subCanvas = this.node.getComponent(cc.Sprite);
    },
    start: function start() {

        if (window.wx != undefined) {
            window.wx.showShareMenu({ withShareTicket: true });
            this.tex = new cc.Texture2D();
            window.sharedCanvas.width = 640;
            window.sharedCanvas.height = 1136;
        }
    },
    _updateSubCanvas: function _updateSubCanvas() {
        if (window.sharedCanvas != undefined && this.tex) {
            this.tex.initWithElement(window.sharedCanvas);
            this.tex.handleLoadedTexture();
            this.subCanvas.spriteFrame = new cc.SpriteFrame(this.tex);
        }
    },
    update: function update() {
        this._updateSubCanvas();
    }
});

cc._RF.pop();