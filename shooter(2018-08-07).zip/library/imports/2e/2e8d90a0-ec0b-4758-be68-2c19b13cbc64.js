"use strict";
cc._RF.push(module, '2e8d9Cg7AtHWL5oLBmxPLxk', 'wexinHandler');
// script/wexinHandler.js

"use strict";

var wexinHandler = {
    submitScore: function submitScore(score) {
        if (window.wx != undefined) {
            window.wx.postMessage({
                messageType: "sendScore",
                score: score
            });
        } else {
            cc.log("fail: x_total : " + score);
        }
    },
    rankList: function rankList() {
        if (window.wx != undefined) {
            window.wx.postMessage({
                messageType: "rankList"
            });
        } else {
            cc.log("fail rank list:");
        }
    },
    rankTop: function rankTop() {
        if (window.wx != undefined) {
            window.wx.postMessage({
                messageType: "rankTop"
            });
        } else {
            cc.log("fail rank Top:");
        }
    }
};
module.exports = wexinHandler;

cc._RF.pop();