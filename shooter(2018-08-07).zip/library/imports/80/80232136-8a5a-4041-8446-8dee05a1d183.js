"use strict";
cc._RF.push(module, '80232E2ilpAQYRGje4FodGD', 'animKilled');
// script/anim/animKilled.js

"use strict";

cc.Class({
    extends: cc.Component,

    init: function init(parent) {
        this.parent = parent;
    },


    hideAnim: function hideAnim() {
        this.parent.despawn();
    }
});

cc._RF.pop();