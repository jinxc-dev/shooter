"use strict";
cc._RF.push(module, '92d98QyZXZCRYIuYQ3L5kV/', 'killed');
// script/anim/killed.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        anim: {
            default: null,
            type: cc.Animation
        }
    },

    onLoad: function onLoad() {
        // this.type = 'enemy';
    },
    start: function start() {},
    init: function init(game, type) {
        this.game = game;
        this.type = type;
        this.anim.getComponent('animKilled').init(this);
    },
    play: function play() {
        if (this.type == 'enemy') {
            this.anim.play('killerEnemy');
        } else if (this.type == 'player') {
            this.anim.play('killerPlayer');
        }
    },
    despawn: function despawn() {
        this.game.despawnKilledAnim(this.node, this.type);
    }
});

cc._RF.pop();