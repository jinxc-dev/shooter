"use strict";
cc._RF.push(module, 'c6d9fJZPt9DCoW8zkDkPRxz', 'enemyHealth');
// script/enemyHealth.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        bar: cc.Node
    },

    start: function start() {},
    onEnable: function onEnable() {
        this.bar.setScale(0, 1);
    },
    upgardeBar: function upgardeBar(cnt) {
        this.bar.runAction(cc.scaleTo(0.2, 0.2 * cnt, 1));
    }
});

cc._RF.pop();