"use strict";
cc._RF.push(module, 'cbb84ytCbNLDrS5eR7oOnvu', 'bullet');
// script/component/bullet.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // onBeginContact: function (contact, selfCollider, otherCollider) {
    //     console.log('bullet Shooter');
    //     // this.despawn();
    // },
    // onCollisionEnd: function (other, self) {
    //     console.log('Shooter OK');
    //     this.node.removeFromParent();
    // },
    onLoad: function onLoad() {
        this.game = null;
    },
    update: function update(dt) {
        var x = this.node.x;
        var boxs = this.node.getBoundingBoxToWorld();
        if (boxs.x < 0 || boxs.x > 640) {
            this.despawn();
        }
    },
    despawn: function despawn() {
        this.node.removeFromParent();
    }
});

cc._RF.pop();