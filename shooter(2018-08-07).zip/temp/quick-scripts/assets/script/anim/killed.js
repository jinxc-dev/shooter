(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/anim/killed.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '92d98QyZXZCRYIuYQ3L5kV/', 'killed', __filename);
// script/anim/killed.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        anim: {
            default: null,
            type: cc.Animation
        }
    },

    onLoad: function onLoad() {
        // this.type = 'enemy';
    },
    start: function start() {},
    init: function init(game, type) {
        this.game = game;
        this.type = type;
        this.anim.getComponent('animKilled').init(this);
    },
    play: function play() {
        if (this.type == 'enemy') {
            this.anim.play('killerEnemy');
        } else if (this.type == 'player') {
            this.anim.play('killerPlayer');
        }
    },
    despawn: function despawn() {
        this.game.despawnKilledAnim(this.node, this.type);
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=killed.js.map
        