(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/bossHealth.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '4eaddWEe0lIMa4axdJUc6gr', 'bossHealth', __filename);
// script/bossHealth.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        title: cc.Node,
        bossIcon: cc.Node,
        healthMask: cc.Node,
        healthBar: cc.Node
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        this.bossInitPos = this.bossIcon.position;
    },
    start: function start() {},
    initMove: function initMove() {
        console.log('bossIcon:' + this.bossInitPos);
        this.bossIcon.position = this.bossInitPos;
        this.bossIcon.setScale(1);
        this.healthMask.active = false;
        this.healthBar.setScale(0, 1);
        this.title.setScale(1);
        this.title.opacity = 255;
        this.node.opacity = 50;
    },
    onEnable: function onEnable() {
        this.initMove();
        this.node.opacity = 50;
        var s2 = cc.fadeIn(1);

        var se = cc.sequence(s2, cc.callFunc(this.endDisplay, this));
        this.node.runAction(se);
    },
    endDisplay: function endDisplay() {
        var s1 = cc.scaleTo(.5, 0.5);
        var s2 = cc.moveTo(.5, 0, 40);
        this.bossIcon.runAction(cc.sequence(s1, s2, cc.callFunc(this.endMove, this)));
        this.title.runAction(cc.scaleTo(.5, 1.5));
        this.title.runAction(cc.fadeOut(0.5));
    },
    endMove: function endMove() {
        this.healthMask.active = true;
        this.healthBar.runAction(cc.scaleTo(0.2, 1));
        // this.node.active = false;
    },
    upgardeBar: function upgardeBar(init, now) {
        var n = now < 0 ? 0 : now;
        this.healthBar.runAction(cc.scaleTo(0.2, n / init, 1));
    }

    // update (dt) {},

});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=bossHealth.js.map
        