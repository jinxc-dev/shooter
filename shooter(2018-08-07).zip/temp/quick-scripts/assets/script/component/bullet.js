(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/component/bullet.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'cbb84ytCbNLDrS5eR7oOnvu', 'bullet', __filename);
// script/component/bullet.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // onBeginContact: function (contact, selfCollider, otherCollider) {
    //     console.log('bullet Shooter');
    //     // this.despawn();
    // },
    // onCollisionEnd: function (other, self) {
    //     console.log('Shooter OK');
    //     this.node.removeFromParent();
    // },
    onLoad: function onLoad() {
        this.game = null;
    },
    update: function update(dt) {
        var x = this.node.x;
        var boxs = this.node.getBoundingBoxToWorld();
        if (boxs.x < 0 || boxs.x > 640) {
            this.despawn();
        }
    },
    despawn: function despawn() {
        this.node.removeFromParent();
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=bullet.js.map
        