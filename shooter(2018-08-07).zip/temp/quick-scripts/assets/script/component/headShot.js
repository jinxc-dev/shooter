(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/component/headShot.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '49eecX7lZpM0ZYo2eC2AAy1', 'headShot', __filename);
// script/component/headShot.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        headCntLabel: cc.Label
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        this.headShotCnt = 0;
        this.headShot = false;
    },
    start: function start() {},
    init: function init() {
        this.headCnt = 0;
        this.headShot = false;
        this.node.active = false;
    },
    checkHeadShot: function checkHeadShot(status) {
        if (status) {
            this.headShot = true;
            this.headCnt++;
            this.headCntLabel.string = "爆头X" + this.headCnt;
            this.runEffect();
        } else {
            this.init();
        }
    },
    runEffect: function runEffect() {
        this.node.setScale(0.5);
        this.node.opacity = 255;
        this.node.active = true;
        var s1 = cc.scaleTo(0.5, 0.8);
        var s2 = cc.fadeOut(1);
        this.node.runAction(cc.sequence(s1, s2));
    },
    endEffect: function endEffect() {
        this.node.active = false;
    }

    // update (dt) {},

});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=headShot.js.map
        