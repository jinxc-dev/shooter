(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/component/player.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '08c3fAy1Z5Oo7yqynrTZr1g', 'player', __filename);
// script/component/player.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        track: {
            default: null,
            type: cc.Graphics
        },

        gunPrefab: {
            default: [],
            type: cc.Prefab
        },
        bulletPrefab: {
            default: null,
            type: cc.Prefab
        }
    },

    onCollisionEnter: function onCollisionEnter(other, self) {
        console.log('Player OK');

        var pos = other.world.position;
        var node_pos = self.node.getPosition();
        var p_y = self.node.parent.y;

        if (other.node.parent.parent.name != 'player') {
            this.game.deadLife();
            this.game.removeAnim(pos, 'player');
        }
        other.node.removeFromParent();

        return;

        // this.node.removeFromParent();
    },
    onLoad: function onLoad() {
        this.runStaus = 0;
        this.pathInfo = {};
        this.step = 0;
        this.stepTime = 0.1;
        this.R = {
            alpha: 0,
            coff: 1,
            step: 3,
            delta: 0,
            rr: 30
        };
        this.shooterReady = true;
        this.game;
        this.gunNum = 0;
        this.gun = null;
        this.bNewGun = false;
        this.bufferCnt = 0;
        // this.newGunNum = 0;
        // this.setGun(this.gunNum, false);
        this.gunNum = parseInt(cc.sys.localStorage.getItem("gun_num"));
    },
    start: function start() {
        this.game = this.node.parent.getComponent('bgMap');
        this.setGun(this.gunNum, false);
    },
    update: function update(dt) {
        if (this.shooterReady) {
            this.drawShooter(dt);
        }
    },
    updatePos: function updatePos(paths, step) {
        this.pathInfo = paths;
        this.runStaus = 1;
        this.step = step;
        this.runMove();
    },
    runMove: function runMove() {
        this.stopShooter();
        var w_runsArray = [];
        var p = this.pathInfo.paths;
        var coff = this.pathInfo.coff;
        var w_t = Math.abs((this.node.x - p[0].x) / this.step) * this.stepTime;

        console.log('time: ' + w_t);

        w_runsArray.push(cc.moveTo(w_t, p[0]));

        for (var i = 1; i < p.length; i++) {
            w_runsArray.push(cc.moveTo(this.stepTime, p[i]));
        }
        w_runsArray.push(cc.moveBy(this.stepTime, this.step * coff, 0));
        w_runsArray.push(cc.callFunc(this.endMove, this));
        var se = cc.sequence(w_runsArray);
        this.node.runAction(se);
        this.runStaus = 0;
    },
    endMove: function endMove() {
        // this.node.setScale(this.pathInfo.coff, 1);
        this.game.getBonus();
        this.game.upgardeEnemyHealth();

        if (this.game.deadBoss) {
            this.runMoveEnd();
        } else {
            this.node.setScale(this.pathInfo.coff, 1);
            this.game.upgardMap();
        }
    },
    drawShooter: function drawShooter(dt) {
        this.R.delta += dt;
        if (this.R.delta < 0.07) {
            return;
        }

        if (this.R.alpha < 0) {
            this.R.coff = 1;
        } else if (this.R.alpha > 45) {
            this.R.coff = -1;
        }
        this.R.alpha += this.R.step * this.R.coff;
        this.drawStrack();

        this.gun.setRotation(this.R.alpha);
        this.R.delta = 0;
    },
    drawStrack: function drawStrack() {

        var r = this.gun.width / 2 + this.aimLen;
        var a = this.calcAlpha(this.R.alpha);
        this.gun.getComponent('gun').setAngle(a);
        var g = this.track;

        if (a < 0) return;
        g.clear();
        g.fillColor = cc.color(0, 0, 0, 100);
        g.arc(0, 0, r, 0, a, true);
        g.lineTo(0, 0);
        g.close();
        g.fill();

        g.strokeColor = cc.color(255, 255, 255, 255);
        g.lineWidth = 2;
        g.moveTo(0, 0);
        g.lineTo(r * Math.cos(a), r * Math.sin(a));
        g.close();
        g.stroke();
    },
    calcAlpha: function calcAlpha(a) {
        return a * Math.PI / 180;
    },
    stopShooter: function stopShooter() {
        this.shooterReady = false;
        this.R = {
            alpha: 0,
            coff: 1,
            step: 3,
            delta: 0,
            rr: 30
        };
        // this.drawStrack();
        this.track.clear();
        this.gun.setRotation(0);
    },
    getAngle: function getAngle() {
        return this.R.alpha;
    },
    setGun: function setGun(n, b_newGun) {
        if (this.gun != null) {
            this.gun.removeChild();
            this.gun.removeFromParent();
            this.gun = null;
        }

        this.bNewGun = b_newGun;

        this.gun = cc.instantiate(this.gunPrefab[n]);
        this.node.addChild(this.gun);
        this.gun.position = cc.v2(0, this.track.node.y);
        this.aimLen = this.gun.getComponent('gun').aimLen;
    },
    startShoot: function startShoot() {
        this.shooterReady = false;
        this.track.clear();
        this.gun.getComponent('gun').startShoot();
    },
    runMoveEnd: function runMoveEnd() {
        this.stopShooter();
        var p = this.pathInfo.paths;
        var coff = this.pathInfo.coff;
        var xx = (coff + 1) * this.game.node.width / 2 - p[p.length - 1].x;
        var s1 = cc.moveBy(0.5, xx, 0);

        var endF = cc.callFunc(this.endMoveEnd, this);
        var se = cc.sequence(s1, endF);
        this.node.runAction(se);
    },
    endMoveEnd: function endMoveEnd() {
        this.game.updateGameLevel();
    },
    setNewGun: function setNewGun(n, buffer) {
        this.setGun(n);
        this.bufferCnt = buffer;
        this.bNewGun = true;
        this.game.bulletCntNode.active = true;
        this.game.bulletCntLabel.string = this.bufferCnt;
    },


    //. now gun status check.
    checkGunStatus: function checkGunStatus() {
        if (this.bNewGun) {
            this.bufferCnt--;

            if (this.bufferCnt < 1) {
                this.bNewGun = false;
                this.setGun(this.gunNum, false);
                this.game.bulletCntNode.active = false;
            } else {
                this.game.bulletCntLabel.string = this.bufferCnt;
                this.game.bulletCntNode.active = true;
            }
        }
    },


    //. gun test function.
    setTestGun: function setTestGun(idx) {
        this.setGun(idx, false);
        this.gun.setRotation(45);
        this.gun.getComponent('gun').setAngle(this.calcAlpha(45));
        this.gun.getComponent('gun').setGunTest(true);
        this.gun.getComponent('gun').startShoot();
    },
    setSelectGunReady: function setSelectGunReady() {
        this.gun.setRotation(45);
        this.gun.getComponent('gun').setAngle(this.calcAlpha(45));
        this.gun.getComponent('gun').setGunTest(true);
    },
    destroySelectGunReady: function destroySelectGunReady() {
        this.gun.setRotation(0);
        this.gun.getComponent('gun').setAngle(0);
        this.gun.getComponent('gun').setGunTest(false);
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=player.js.map
        