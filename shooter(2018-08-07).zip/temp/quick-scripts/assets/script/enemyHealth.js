(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/enemyHealth.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'c6d9fJZPt9DCoW8zkDkPRxz', 'enemyHealth', __filename);
// script/enemyHealth.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        bar: cc.Node
    },

    start: function start() {},
    onEnable: function onEnable() {
        this.bar.setScale(0, 1);
    },
    upgardeBar: function upgardeBar(cnt) {
        this.bar.runAction(cc.scaleTo(0.2, 0.2 * cnt, 1));
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=enemyHealth.js.map
        