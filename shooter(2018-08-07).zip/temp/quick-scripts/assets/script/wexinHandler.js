(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/wexinHandler.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '2e8d9Cg7AtHWL5oLBmxPLxk', 'wexinHandler', __filename);
// script/wexinHandler.js

"use strict";

var wexinHandler = {
    submitScore: function submitScore(score) {
        if (window.wx != undefined) {
            window.wx.postMessage({
                messageType: "sendScore",
                score: score
            });
        } else {
            cc.log("fail: x_total : " + score);
        }
    },
    rankList: function rankList() {
        if (window.wx != undefined) {
            window.wx.postMessage({
                messageType: "rankList"
            });
        } else {
            cc.log("fail rank list:");
        }
    },
    rankTop: function rankTop() {
        if (window.wx != undefined) {
            window.wx.postMessage({
                messageType: "rankTop"
            });
        } else {
            cc.log("fail rank Top:");
        }
    }
};
module.exports = wexinHandler;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=wexinHandler.js.map
        